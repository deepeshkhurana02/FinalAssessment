package create;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateMethod {
	   public static void createM() {
		   try {
			   Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "JaiMataDi@91");
			   String create = "CREATE TABLE IF NOT EXISTS record (" + 
			   		"    `Reg_No` INT," + 
			   		"    `Roll_No' INT," + 
			   		"    `Father_Name varchar (50)," + 
			   		"    `Mother_Name varchar(50)," + 
			   		"    `Course varchar(100)," + 
			   		"    `Semester INT," + 
			   		"    `Year INT," + 
			   		");";
			   Statement stmt = conn.createStatement();
			   stmt.executeUpdate(create);
		   }
		   catch(Exception e) {
			   e.printStackTrace();
		   }
	   }
}
