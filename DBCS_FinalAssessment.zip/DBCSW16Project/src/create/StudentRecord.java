package create;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class StudentRecord {

	public static void insert(String combo, String txt) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root",
					"Root@123");
			con.setAutoCommit(false);
			PreparedStatement pstm = null;
			FileInputStream input = new FileInputStream(txt);
			@SuppressWarnings("unused")
			String fs = input.toString();
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(new FileInputStream(txt));
			XSSFSheet sheet = wb.getSheetAt(0);
			Row row;
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				row = sheet.getRow(i);
				int Reg_No = (int) row.getCell(0).getNumericCellValue();
				int Roll_No = (int) row.getCell(0).getNumericCellValue();
				String Father_Name = (String) row.getCell(1).getStringCellValue();
				String Mother_Name = (String) row.getCell(1).getStringCellValue();
				String Course = (String) row.getCell(1).getStringCellValue();
				String Semester = (String) row.getCell(1).getStringCellValue();
				int Year = (int) row.getCell(5).getNumericCellValue();
			
				

				String sql = "INSERT INTO student(Reg_No," + "Roll_No," + "Father_Name," + "Mother_Name," + "Course,"
						+ "Semester," + "Year) VALUES('" + Reg_No + Roll_No + "','" + Father_Name + "','" + Mother_Name
						+ "','" + Course + "','" + Semester + "','" + Year + "')";
				pstm = (PreparedStatement) con.prepareStatement(sql);
				pstm.execute();
				System.out.println("Import rows " + i);
			}
			con.commit();
			pstm.close();
			con.close();
			input.close();
			System.out.println("Success import excel to mysql table");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException ex) {
			System.out.println(ex);
		} catch (IOException ioe) {
			System.out.println(ioe);
		}

	}
}